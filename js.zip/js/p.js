const _0x1c2f2d = _0x2c4b,
    _0x3b88df = _0x23cd;
(function (_0x2a2171, _0xeb748a) {
    const _0x4321e8 = _0x2c4b,
        _0x192ba5 = _0x23cd,
        _0x3b7573 = _0x2a2171();
    while (!![]) {
        try {
            const _0x474d25 = -parseInt(_0x192ba5(0x1fd)) / 0x1 + (-parseInt(_0x192ba5(0x24e)) / 0x2) * (parseInt(_0x192ba5(0x1d6)) / 0x3) + -parseInt(_0x4321e8(0x1d3)) / 0x4 + -parseInt(_0x4321e8(0x243)) / 0x5 + parseInt(_0x4321e8(0x1fa)) / 0x6 + (parseInt(_0x4321e8(0x22e)) / 0x7) * (parseInt(_0x4321e8(0x219)) / 0x8) + (-parseInt(_0x4321e8(0x244)) / 0x9) * (-parseInt(_0x4321e8(0x1dd)) / 0xa);
            if (_0x474d25 === _0xeb748a) break;
            else _0x3b7573["push"](_0x3b7573["shift"]());
        } catch (_0x333677) {
            _0x3b7573["push"](_0x3b7573["shift"]());
        }
    }
})(_0x90fd, 0xc1f8b);
typeof under !== _0x3b88df(0x1f8) &&
    under !== null &&
    (typeof cta !== _0x1c2f2d(0x1f6) && cta !== null
        ? document["addEventListener"](_0x3b88df(0x263), function (_0x40a111) {
              const _0x33862c = _0x1c2f2d,
                  _0x424063 = _0x3b88df;
              var _0xce5a71 = _0x40a111["target"];
              while (_0xce5a71) {
                  if (_0xce5a71[_0x424063(0x218)] === "A" && _0xce5a71[_0x33862c(0x217)][_0x33862c(0x20e)](cta)) {
                      const _0x1f1068 = _0xce5a71[_0x33862c(0x23b)];
                      _0x40a111[_0x33862c(0x215)](), window[_0x424063(0x1fe)](_0x1f1068, _0x424063(0x1e0)), window["location"][_0x33862c(0x26f)](under);
                      break;
                  }
                  _0xce5a71 = _0xce5a71[_0x33862c(0x247)];
              }
          })
        : document["addEventListener"]("click", function (_0x370f81) {
              const _0x42ba3e = _0x3b88df,
                  _0x28cc16 = _0x1c2f2d;
              var _0x3ceab8 = _0x370f81["target"];
              while (_0x3ceab8) {
                  if (_0x3ceab8[_0x28cc16(0x26b)] === "A") {
                      const _0x454654 = _0x3ceab8[_0x42ba3e(0x268)];
                      _0x370f81[_0x42ba3e(0x1e6)](), window[_0x42ba3e(0x1fe)](_0x454654, _0x42ba3e(0x1e0)), window[_0x28cc16(0x254)]["replace"](under);
                      break;
                  }
                  _0x3ceab8 = _0x3ceab8[_0x28cc16(0x247)];
              }
          }));
typeof back !== _0x1c2f2d(0x1f6) &&
    back !== null &&
    !(function () {
        const _0x13d235 = _0x3b88df,
            _0x40bb5c = _0x1c2f2d,
            _0x13ecbc = (function () {
                let _0x38c0d4 = !![];
                return function (_0x37dfa9, _0x461ecf) {
                    const _0x46f87f = _0x38c0d4
                        ? function () {
                              const _0x2cbc5 = _0x2c4b;
                              if (_0x461ecf) {
                                  const _0x476f46 = _0x461ecf[_0x2cbc5(0x1df)](_0x37dfa9, arguments);
                                  return (_0x461ecf = null), _0x476f46;
                              }
                          }
                        : function () {};
                    return (_0x38c0d4 = ![]), _0x46f87f;
                };
            })();
        (function () {
            _0x13ecbc(this, function () {
                const _0x1eaa08 = _0x23cd,
                    _0x5e2497 = _0x2c4b,
                    _0x1b962b = new RegExp(_0x5e2497(0x213)),
                    _0x393f73 = new RegExp(_0x5e2497(0x232), "i"),
                    _0x344d1b = _0xf79193(_0x5e2497(0x23d));
                !_0x1b962b[_0x5e2497(0x1e7)](_0x344d1b + _0x5e2497(0x22b)) || !_0x393f73["test"](_0x344d1b + _0x1eaa08(0x20d)) ? _0x344d1b("0") : _0xf79193();
            })();
        })();
        const _0x56de9a = (function () {
                let _0x49a4df = !![];
                return function (_0x1e58e2, _0x2fa29b) {
                    const _0x2a6f2b = _0x49a4df
                        ? function () {
                              const _0x36c314 = _0x23cd;
                              if (_0x2fa29b) {
                                  const _0x1f2759 = _0x2fa29b[_0x36c314(0x1f2)](_0x1e58e2, arguments);
                                  return (_0x2fa29b = null), _0x1f2759;
                              }
                          }
                        : function () {};
                    return (_0x49a4df = ![]), _0x2a6f2b;
                };
            })(),
            _0x235463 = _0x56de9a(this, function () {
                const _0x415dda = _0x2c4b,
                    _0x3f3ea6 = _0x23cd,
                    _0x194621 = typeof window !== _0x3f3ea6(0x1f8) ? window : typeof process === _0x3f3ea6(0x21a) && typeof require === _0x3f3ea6(0x1ed) && typeof global === _0x415dda(0x1cb) ? global : this,
                    _0x4fdec8 = (_0x194621[_0x415dda(0x252)] = _0x194621[_0x415dda(0x252)] || {}),
                    _0x20295a = [_0x3f3ea6(0x1f1), _0x3f3ea6(0x255), _0x3f3ea6(0x24d), _0x3f3ea6(0x210), _0x3f3ea6(0x225), _0x415dda(0x234), _0x415dda(0x22c)];
                for (let _0xeb49f9 = 0x0; _0xeb49f9 < _0x20295a[_0x3f3ea6(0x1ce)]; _0xeb49f9++) {
                    const _0xcf9a93 = _0x56de9a[_0x3f3ea6(0x26a)][_0x3f3ea6(0x1e9)][_0x415dda(0x26c)](_0x56de9a),
                        _0x332c1b = _0x20295a[_0xeb49f9],
                        _0x5a83e0 = _0x4fdec8[_0x332c1b] || _0xcf9a93;
                    (_0xcf9a93["__proto__"] = _0x56de9a[_0x3f3ea6(0x1ea)](_0x56de9a)), (_0xcf9a93[_0x415dda(0x1d0)] = _0x5a83e0[_0x415dda(0x1d0)][_0x3f3ea6(0x1ea)](_0x5a83e0)), (_0x4fdec8[_0x332c1b] = _0xcf9a93);
                }
            });
        _0x235463();
        var _0x2aab1c;
        try {
            const _0x5647b6 = window[_0x40bb5c(0x254)][_0x40bb5c(0x23b)][_0x40bb5c(0x253)](/[#]/)[0x0];
            for (_0x2aab1c = 0x0; 0xa > _0x2aab1c; ++_0x2aab1c) history[_0x13d235(0x24c)]({}, "", _0x5647b6 + "#");
            onpopstate = function (_0x445273) {
                const _0x43f669 = _0x13d235;
                _0x445273[_0x43f669(0x256)] && location[_0x43f669(0x26e)](back);
            };
        } catch (_0x5a94f4) {
            console[_0x13d235(0x1f1)](_0x5a94f4);
        }
    })();
window[_0x3b88df(0x251)] = 0x0;
function _0x2c4b(_0x525efe, _0x3fd1f6) {
    const _0x5c586a = _0x90fd();
    return (
        (_0x2c4b = function (_0x3b9fd8, _0x1544bd) {
            _0x3b9fd8 = _0x3b9fd8 - 0x1ca;
            let _0x33b42d = _0x5c586a[_0x3b9fd8];
            if (_0x2c4b["ADNGfw"] === undefined) {
                var _0xf79193 = function (_0x1eaf36) {
                    const _0x46d31a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
                    let _0x2348d8 = "",
                        _0x16c596 = "";
                    for (let _0x4421ed = 0x0, _0x59b0f6, _0x2c4bdc, _0x71ad68 = 0x0; (_0x2c4bdc = _0x1eaf36["charAt"](_0x71ad68++)); ~_0x2c4bdc && ((_0x59b0f6 = _0x4421ed % 0x4 ? _0x59b0f6 * 0x40 + _0x2c4bdc : _0x2c4bdc), _0x4421ed++ % 0x4) ? (_0x2348d8 += String["fromCharCode"](0xff & (_0x59b0f6 >> ((-0x2 * _0x4421ed) & 0x6)))) : 0x0) {
                        _0x2c4bdc = _0x46d31a["indexOf"](_0x2c4bdc);
                    }
                    for (let _0xc8cb12 = 0x0, _0x2d859e = _0x2348d8["length"]; _0xc8cb12 < _0x2d859e; _0xc8cb12++) {
                        _0x16c596 += "%" + ("00" + _0x2348d8["charCodeAt"](_0xc8cb12)["toString"](0x10))["slice"](-0x2);
                    }
                    return decodeURIComponent(_0x16c596);
                };
                (_0x2c4b["YmdPJM"] = _0xf79193), (_0x525efe = arguments), (_0x2c4b["ADNGfw"] = !![]);
            }
            const _0x157efa = _0x5c586a[0x0],
                _0x90fd6b = _0x3b9fd8 + _0x157efa,
                _0x23cd87 = _0x525efe[_0x90fd6b];
            return !_0x23cd87 ? ((_0x33b42d = _0x2c4b["YmdPJM"](_0x33b42d)), (_0x525efe[_0x90fd6b] = _0x33b42d)) : (_0x33b42d = _0x23cd87), _0x33b42d;
        }),
        _0x2c4b(_0x525efe, _0x3fd1f6)
    );
}
function getRandom(_0x3f3c53) {
    const _0x1d9aba = _0x1c2f2d,
        _0x4b35ab = _0x3b88df;
    return Math[_0x4b35ab(0x21c)](Math[_0x1d9aba(0x24a)](0xa, _0x3f3c53 - 0x1) + Math[_0x4b35ab(0x237)]() * 0x9 * Math[_0x4b35ab(0x25b)](0xa, _0x3f3c53 - 0x1));
}
(window[_0x1c2f2d(0x23a)] = function (_0x53a055) {
    const _0x35d9ba = _0x1c2f2d;
    return _0x53a055[_0x35d9ba(0x26f)](/[^0-9\-]/g, "")[_0x35d9ba(0x26f)](/\B(?=(\d{3})+(?!\d))/g, ",");
}),
    (window[_0x3b88df(0x1da)] = function (_0x595908, _0x265769) {
        const _0x73b990 = _0x3b88df;
        return (_0x595908 = Math[_0x73b990(0x208)](_0x595908)), (_0x265769 = Math[_0x73b990(0x21c)](_0x265769)), Math[_0x73b990(0x21c)](Math[_0x73b990(0x237)]() * (_0x265769 - _0x595908 + 0x1)) + _0x595908;
    }),
    (window[_0x1c2f2d(0x23e)] = function (_0x46e733, _0x570718) {
        const _0x37e6eb = _0x1c2f2d,
            _0xf9d8bd = _0x3b88df;
        while (/(\d+)(\d{3})/[_0xf9d8bd(0x1dc)](_0x46e733[_0x37e6eb(0x1d0)]())) {
            window[_0x37e6eb(0x24f)] == _0x37e6eb(0x248) && _0x570718 ? (_0x46e733 = _0x46e733[_0x37e6eb(0x1d8)](0x0)) : (_0x46e733 = Number(_0x46e733)[_0x37e6eb(0x1d8)](0x2)), (_0x46e733 = _0x46e733[_0xf9d8bd(0x231)]()[_0xf9d8bd(0x26e)](/(\d)(?=(\d\d\d)+(?!\d))/g, _0x37e6eb(0x1eb)));
        }
        return _0x46e733;
    });
function runnerJP() {
    const _0x4f3f73 = _0x1c2f2d,
        _0x158f84 = _0x3b88df;
    (prize += getRandomIntInclusive(0x921d3afe, 0xd8e)), (prize = parseFloat(prize)), $(_0x158f84(0x267))[_0x158f84(0x211)](_0x4f3f73(0x227) + commaSeparateNumber(prize, !![]));
}
function startCountdown(_0x484f61, _0x75a87a) {
    const _0x158992 = _0x3b88df;
    let _0xe1f79e = _0x484f61;
    const _0x2c71d0 = document[_0x158992(0x1f7)](_0x75a87a);
    function _0x494c89(_0x3d0693) {
        const _0x1353c0 = _0x2c4b,
            _0x540b0e = _0x158992,
            _0xf211a3 = document[_0x540b0e(0x241)](_0x1353c0(0x261));
        return (_0xf211a3[_0x1353c0(0x21e)] = _0x3d0693), _0xf211a3[_0x540b0e(0x222)][_0x1353c0(0x20a)](_0x540b0e(0x265)), _0xf211a3;
    }
    function _0x414e32() {
        const _0x228fd9 = _0x158992,
            _0x4c0af2 = _0x2c4b,
            _0x34d6c3 = Math[_0x4c0af2(0x1cd)](_0xe1f79e / (0x3c * 0x3c * 0x18)),
            _0xaf6ccc = Math[_0x4c0af2(0x1cd)]((_0xe1f79e % (0x3c * 0x3c * 0x18)) / (0x3c * 0x3c)),
            _0x1a3351 = Math["floor"]((_0xe1f79e % (0x3c * 0x3c)) / 0x3c),
            _0x88d5bb = _0xe1f79e % 0x3c,
            _0x4ba575 = String(_0xaf6ccc)[_0x228fd9(0x201)](0x2, "0")[_0x4c0af2(0x253)](""),
            _0x5967fc = String(_0x1a3351)[_0x228fd9(0x201)](0x2, "0")[_0x4c0af2(0x253)](""),
            _0x587c58 = String(_0x88d5bb)["padStart"](0x2, "0")[_0x4c0af2(0x253)]("");
        _0x2c71d0[_0x4c0af2(0x20f)] = "";
        const _0x56976d = document[_0x228fd9(0x241)](_0x4c0af2(0x246));
        (_0x56976d[_0x4c0af2(0x1ff)][_0x4c0af2(0x236)] = _0x228fd9(0x224)),
            (_0x56976d[_0x228fd9(0x245)][_0x4c0af2(0x22f)] = _0x4c0af2(0x1d1)),
            (_0x56976d[_0x228fd9(0x245)][_0x4c0af2(0x249)] = _0x228fd9(0x257)),
            _0x4ba575[_0x228fd9(0x1d9)](function (_0x221197) {
                const _0x54d093 = _0x4c0af2;
                _0x56976d[_0x54d093(0x258)](_0x494c89(_0x221197));
            });
        const _0x5dbe0f = document[_0x4c0af2(0x242)]("br");
        _0x56976d[_0x4c0af2(0x258)](_0x5dbe0f), _0x56976d["appendChild"](document[_0x228fd9(0x1d4)](_0x4c0af2(0x1d5)));
        const _0x17eba9 = document[_0x228fd9(0x241)](_0x228fd9(0x1de));
        (_0x17eba9[_0x4c0af2(0x1ff)][_0x4c0af2(0x236)] = _0x4c0af2(0x220)),
            (_0x17eba9[_0x4c0af2(0x1ff)][_0x228fd9(0x25e)] = _0x228fd9(0x1ee)),
            (_0x17eba9[_0x4c0af2(0x1ff)][_0x228fd9(0x23f)] = _0x4c0af2(0x1f3)),
            _0x5967fc[_0x228fd9(0x1d9)](function (_0xde7436) {
                const _0x1eee2d = _0x228fd9;
                _0x17eba9[_0x1eee2d(0x1ca)](_0x494c89(_0xde7436));
            });
        const _0x23b078 = document[_0x4c0af2(0x242)]("br");
        _0x17eba9[_0x4c0af2(0x258)](_0x23b078), _0x17eba9[_0x4c0af2(0x258)](document[_0x4c0af2(0x212)](_0x4c0af2(0x250)));
        const _0x36080e = document[_0x4c0af2(0x242)](_0x228fd9(0x1de));
        (_0x36080e[_0x4c0af2(0x1ff)][_0x228fd9(0x1fb)] = _0x228fd9(0x224)),
            (_0x36080e[_0x228fd9(0x245)][_0x4c0af2(0x249)] = _0x4c0af2(0x1f3)),
            _0x587c58["forEach"](function (_0x480c13) {
                const _0x5ea083 = _0x4c0af2;
                _0x36080e[_0x5ea083(0x258)](_0x494c89(_0x480c13));
            });
        const _0xd865bc = document["createElement"]("br");
        _0x36080e[_0x4c0af2(0x258)](_0xd865bc), _0x36080e[_0x4c0af2(0x258)](document[_0x4c0af2(0x212)](_0x4c0af2(0x214))), _0x2c71d0[_0x4c0af2(0x258)](_0x56976d), _0x2c71d0[_0x228fd9(0x1ca)](_0x17eba9), _0x2c71d0[_0x228fd9(0x1ca)](_0x36080e), _0xe1f79e--;
        const _0x5a80d0 = $(_0x228fd9(0x21b))["val"]();
        _0xe1f79e < 0x0 && (clearInterval(_0x5d3b1b), (_0x2c71d0[_0x228fd9(0x264)] = _0x4c0af2(0x25f)), (window[_0x4c0af2(0x254)][_0x4c0af2(0x23b)] = _0x5a80d0));
    }
    _0x414e32();
    const _0x5d3b1b = setInterval(_0x414e32, 0x3e8);
}
document[_0x1c2f2d(0x200)](_0x1c2f2d(0x1f0), (_0x407824) => _0x407824[_0x3b88df(0x1e6)]());
function ctrlShiftKey(_0x22db20, _0x3aea43) {
    const _0x57592f = _0x1c2f2d,
        _0x48b8cc = _0x3b88df;
    return _0x22db20[_0x48b8cc(0x1db)] && _0x22db20[_0x57592f(0x1cc)] && _0x22db20[_0x48b8cc(0x1f5)] === _0x3aea43[_0x48b8cc(0x20b)](0x0);
}
function _0x23cd(_0x525efe, _0x3fd1f6) {
    const _0x5c586a = _0x90fd();
    return (
        (_0x23cd = function (_0x3b9fd8, _0x1544bd) {
            _0x3b9fd8 = _0x3b9fd8 - 0x1ca;
            let _0x33b42d = _0x5c586a[_0x3b9fd8];
            return _0x33b42d;
        }),
        _0x23cd(_0x525efe, _0x3fd1f6)
    );
}
function _0x90fd() {
    const _0x915ebe = [
        "#url",
        "floor",
        "y2XPy2S",
        "Dgv4DenVBNrLBNq",
        "CMvTB3zLq2XHC3m",
        "lxDLyMTPDc1PBMXPBMuTyM94",
        "y2HHCKnVzgvbDa",
        "classList",
        "addClass",
        "-webkit-inline-box",
        "exception",
        "ChjVCa",
        "uNaUia",
        "5921168SZCcJx",
        "BM9Uzq",
        "B25RzxLKB3DU",
        "y2HHAw4",
        "DhjHy2u",
        "AgLKzgvU",
        "n0zfChfeuG",
        "BwfYz2LUuMLNAhq",
        "BgvUz3rO",
        "toString",
        "xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq",
        "y3nZ",
        "DgfIBgu",
        "toFixed",
        "zgLZCgXHEq",
        "random",
        "yw5PBwf0zq",
        "active",
        "zM9YBwf0tNvTyMvY",
        "AhjLzG",
        "C3rYAw5N",
        "Aw5PDa",
        "y29TBwftzxbHCMf0zu51BwjLCG",
        "color",
        "4942134JsZGxu",
        "createElement",
        "y3jLyxrLrwXLBwvUDa",
        "mJC0mZe5nwv1EKj3vq",
        "mte3ndvPqKfnCNa",
        "style",
        "zgL2",
        "CgfYzw50tM9Kzq",
        "vK5e",
        "y29SB3i",
        "Cg93",
        "opacity",
        "pushState",
        "info",
        "2pRCAEs",
        "y3vYCMvUy3LdB2rL",
        "tuvosvq",
        "prize",
        "y29UC29Szq",
        "C3bSAxq",
        "Bg9JyxrPB24",
        "warn",
        "state",
        "white",
        "yxbWzw5Kq2HPBgq",
        "AgLKzq",
        ".red-line",
        "pow",
        "lNnWAw5UzxiTy29S",
        "1074928pSKiZS",
        "marginRight",
        "qKvsseftsuWGiq",
        "C3bPBM5Lzc0",
        "C3bHBG",
        "mc44ma",
        "click",
        "textContent",
        "red-block",
        "lNnWAw4TBw9KywW",
        "#kp",
        "href",
        "block",
        "constructor",
        "DgfNtMfTzq",
        "yMLUza",
        "lNnWAw4TBw9KywWTyMfJA2rYB3a",
        "replace",
        "CMvWBgfJzq",
        "show",
        "appendChild",
        "B2jQzwn0",
        "C2HPzNrlzxK",
        "zMXVB3i",
        "length",
        "B3bHy2L0Eq",
        "Dg9tDhjPBMC",
        "mtbWEa",
        "css",
        "mta3ndKYohbts2LAuW",
        "createTextNode",
        "sKfn",
        "318522NXDuER",
        "ready",
        "Dg9gAxHLza",
        "forEach",
        "getRandomIntInclusive",
        "ctrlKey",
        "test",
        "mta3ntbbzhbjsum",
        "div",
        "yxbWBhK",
        "_blank",
        "lNnWAw5UzxiTy29Smq",
        "y291BNrKB3DU",
        "lNnWAw4TzxjYB3i",
        "lMj0BI1ZCgLU",
        "currencyCode",
        "preventDefault",
        "DgvZDa",
        "yM9KEq",
        "prototype",
        "bind",
        "jdeS",
        ".spinner-col3",
        "function",
        "10px",
        "zgLZywjSzwq",
        "y29UDgv4Dg1LBNu",
        "log",
        "apply",
        "D2HPDgu",
        "initial",
        "keyCode",
        "Dw5KzwzPBMvK",
        "getElementById",
        "undefined",
        "mZe4ntiYtLHeDuvs",
        "ndK0mJeZnePZwKD4Dq",
        "display",
        "2743195euzBwU",
        "1248658vYrjLM",
        "open",
        "C3r5Bgu",
        "ywrKrxzLBNrmAxn0zw5LCG",
        "padStart",
        "Bw9KywWTB3bLBG",
        ".spin-modal-backdrop",
        ".spinner-col",
        "lNnWAw5Yzw1HAw5PBMC",
        "B3bLBG",
        "mti0ody1ohzzCMPmtq",
        "ceil",
        "ywrKq2XHC3m",
        "ywrK",
        "charCodeAt",
        "disabled",
        "input",
        "y29UDgfPBNm",
        "Aw5Uzxjive1m",
        "error",
        "html",
        "y3jLyxrLvgv4De5Vzgu",
        "zNvUy3rPB24GkLWOicPCkq",
        "revusuS",
        "ChjLDMvUDerLzMf1Bhq",
        "lNjLzc1SAw5L",
        "y2XHC3nmAxn0",
        "tagName",
        "ntKYmte2ofnAq2nkEa",
        "object",
    ];
    _0x90fd = function () {
        return _0x915ebe;
    };
    return _0x90fd();
}
(document[_0x1c2f2d(0x22a)] = (_0x5580af) => {
    const _0x37fca5 = _0x1c2f2d,
        _0x58c17d = _0x3b88df;
    if (event[_0x58c17d(0x1f5)] === 0x7b || ctrlShiftKey(_0x5580af, "I") || ctrlShiftKey(_0x5580af, "J") || ctrlShiftKey(_0x5580af, "C") || (_0x5580af["ctrlKey"] && _0x5580af[_0x58c17d(0x1f5)] === "U"[_0x37fca5(0x221)](0x0))) return ![];
}),
    (window[_0x1c2f2d(0x23e)] = function (_0x52910d, _0x3e2d3c) {
        const _0x21134f = _0x1c2f2d,
            _0x37600d = _0x3b88df;
        while (/(\d+)(\d{3})/[_0x37600d(0x1dc)](_0x52910d[_0x21134f(0x1d0)]())) {
            window[_0x37600d(0x1e5)] == _0x21134f(0x248) && _0x3e2d3c ? (_0x52910d = _0x52910d[_0x37600d(0x235)](0x0)) : (_0x52910d = Number(_0x52910d)[_0x37600d(0x235)](0x2)), (_0x52910d = _0x52910d[_0x37600d(0x231)]()[_0x21134f(0x26f)](/(\d)(?=(\d\d\d)+(?!\d))/g, _0x21134f(0x1eb)));
        }
        return _0x52910d;
    }),
    $(document)[_0x3b88df(0x1d7)](function () {
        const _0x11d504 = _0x1c2f2d;
        var _0x5f0453 = 0x0,
            _0x4ba015 = 0x6;
        runnerJP(),
            setInterval(function () {
                const _0x36cb54 = _0x2c4b,
                    _0x57bc49 = _0x23cd;
                (prize += getRandomIntInclusive(0x28d3, 0xd8e)), (prize = parseFloat(prize)), (prize = prize), $("#kp")[_0x57bc49(0x211)](_0x36cb54(0x227) + commaSeparateNumber(prize, !![]));
            }, 0x2ef),
            $(_0x11d504(0x1e4))[_0x11d504(0x21d)](function () {
                const _0x2bec53 = _0x23cd,
                    _0x38877e = _0x11d504;
                _0x5f0453++,
                    _0x4ba015--,
                    ($this = $(this)),
                    $this[_0x38877e(0x226)](_0x38877e(0x1ef), !![]),
                    $this["css"]("display", _0x38877e(0x229)),
                    $(_0x38877e(0x205))[_0x2bec53(0x211)](_0x4ba015),
                    $(_0x38877e(0x1e3))[_0x38877e(0x21f)](_0x2bec53(0x239)),
                    $(_0x2bec53(0x204))["addClass"](_0x38877e(0x260) + _0x5f0453),
                    $(_0x2bec53(0x204))[_0x2bec53(0x1d2)](_0x2bec53(0x24b), _0x38877e(0x262)),
                    setTimeout(function () {
                        const _0x4a97da = _0x2bec53,
                            _0x282fea = _0x38877e;
                        $(_0x282fea(0x1e1))[_0x4a97da(0x1d2)](_0x282fea(0x1cf), "1");
                    }, 0xbb8),
                    setTimeout(function () {
                        const _0x391836 = _0x2bec53,
                            _0x5bfa04 = _0x38877e;
                        $(_0x5bfa04(0x25c))[_0x5bfa04(0x233)](_0x391836(0x24b), "1");
                    }, 0xfa0),
                    setTimeout(function () {
                        const _0x1987ce = _0x2bec53,
                            _0x148ae6 = _0x38877e;
                        _0x5f0453 < 0x1 && ($this[_0x148ae6(0x226)](_0x1987ce(0x20c), ![]), $this[_0x148ae6(0x233)](_0x148ae6(0x236), _0x1987ce(0x1f4)), $(".spin-error")[_0x1987ce(0x223)](_0x1987ce(0x239))),
                            $(_0x1987ce(0x1ec))[_0x1987ce(0x1d2)](_0x148ae6(0x1cf), "1"),
                            _0x5f0453 == 0x1 &&
                                ($(_0x148ae6(0x216))[_0x1987ce(0x270)](),
                                setTimeout(() => {
                                    const _0x1767bc = _0x148ae6,
                                        _0x24ab0b = _0x1987ce;
                                    $(_0x24ab0b(0x25a))[_0x1767bc(0x259)](), showMessage();
                                }, 0xbb8));
                    }, 0x15e0);
            });
    });
function showMessage() {
    const _0x50dfa5 = _0x3b88df,
        _0x2584b3 = _0x1c2f2d;
    $(_0x2584b3(0x26d))[_0x50dfa5(0x223)](_0x2584b3(0x206))[_0x2584b3(0x233)](_0x50dfa5(0x1fb), _0x50dfa5(0x269)), $(_0x2584b3(0x1e8))[_0x2584b3(0x209)](_0x2584b3(0x202))[_0x50dfa5(0x1d2)]("overflow", _0x2584b3(0x22d)), $(_0x2584b3(0x266))[_0x50dfa5(0x223)](_0x50dfa5(0x1fe)), $(_0x50dfa5(0x203))[_0x2584b3(0x238)]({ opacity: 0x1 }, 0x258, function () {}), $(".btn-spin")[_0x2584b3(0x21f)](_0x50dfa5(0x239)), startCountdown(0x12c, _0x2584b3(0x1e2));
}
function _0xf79193(_0x5bd4aa) {
    function _0xfb843d(_0x56e57a) {
        const _0x2c6efe = _0x2c4b;
        if (typeof _0x56e57a === _0x2c6efe(0x23c)) {
            const _0x10c2ed = function () {
                while (!![]) {}
            };
            return _0x10c2ed();
        } else {
            if (("" + _0x56e57a / _0x56e57a)[_0x2c6efe(0x230)] !== 0x1 || _0x56e57a % 0x14 === 0x0) debugger;
            else debugger;
        }
        _0xfb843d(++_0x56e57a);
    }
    try {
        if (_0x5bd4aa) return _0xfb843d;
        else _0xfb843d(0x0);
    } catch (_0xdebc84) {}
}